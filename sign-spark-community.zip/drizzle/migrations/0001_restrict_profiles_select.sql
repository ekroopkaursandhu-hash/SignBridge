DROP POLICY IF EXISTS "profiles readable by signed in" ON public.profiles;
CREATE POLICY "own profile select" ON public.profiles FOR SELECT TO authenticated USING (auth.uid() = id);