export type CallSignal = {
  from: string;
  to?: string;
  sdp?: RTCSessionDescriptionInit;
  candidate?: RTCIceCandidateInit;
};

// One elected caller creates offers; all incoming messages are processed in order.
export class CallConnection {
  private remoteId: string | null = null;
  private offered = false;
  private closed = false;
  private pending: RTCIceCandidateInit[] = [];
  private queue: Promise<void> = Promise.resolve();

  constructor(
    private peer: RTCPeerConnection,
    private id: string,
    private send: (event: string, payload: Record<string, unknown>) => void,
    private onError: (error: unknown) => void,
  ) {
    peer.onicecandidate = ({ candidate }) => {
      if (candidate && this.remoteId) this.send("ice", { to: this.remoteId, candidate: candidate.toJSON() });
    };
  }

  receive(event: string, signal: CallSignal): Promise<void> {
    this.queue = this.queue.then(async () => {
      if (this.closed || signal.from === this.id || (signal.to && signal.to !== this.id)) return;
      if (!signal.from || (this.remoteId && this.remoteId !== signal.from)) return;
      this.remoteId = signal.from;
      if (event === "hello") {
        this.send("ready", { to: signal.from });
        await this.offer();
      } else if (event === "ready") {
        await this.offer();
      } else if (event === "offer" && signal.sdp && this.id > signal.from) {
        await this.peer.setRemoteDescription(signal.sdp);
        await this.flushCandidates();
        const answer = await this.peer.createAnswer();
        await this.peer.setLocalDescription(answer);
        this.send("answer", { to: signal.from, sdp: this.peer.localDescription });
      } else if (event === "answer" && signal.sdp && this.peer.signalingState === "have-local-offer") {
        await this.peer.setRemoteDescription(signal.sdp);
        await this.flushCandidates();
      } else if (event === "ice" && signal.candidate) {
        if (this.peer.remoteDescription) await this.peer.addIceCandidate(signal.candidate);
        else this.pending.push(signal.candidate);
      }
    }).catch(this.onError);
    return this.queue;
  }

  private async offer() {
    if (this.closed || !this.remoteId || this.id > this.remoteId || this.offered) return;
    this.offered = true;
    const offer = await this.peer.createOffer();
    await this.peer.setLocalDescription(offer);
    this.send("offer", { to: this.remoteId, sdp: this.peer.localDescription });
  }

  private async flushCandidates() {
    for (const candidate of this.pending.splice(0)) await this.peer.addIceCandidate(candidate);
  }

  close() {
    this.closed = true;
    this.pending = [];
    this.peer.onicecandidate = null;
    this.peer.close();
  }
}