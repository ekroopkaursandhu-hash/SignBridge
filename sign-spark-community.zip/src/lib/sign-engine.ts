// Pure, browser-safe ASL recognition logic (no MediaPipe import here, so it is unit-testable).
export type Point = { x: number; y: number; z: number };
export type Vec = number[];

export const SEQ_LEN = 20;

/** Translate to wrist, scale by wrist→middle-MCP length, flatten to 63 numbers. */
export function normalize(lm: Point[]): Vec {
  const w = lm[0]!;
  const ref = lm[9]!;
  const s = Math.hypot(ref.x - w.x, ref.y - w.y, ref.z - w.z) || 1;
  const out: Vec = [];
  for (const p of lm) out.push((p.x - w.x) / s, (p.y - w.y) / s, (p.z - w.z) / s);
  return out;
}

export function dist(a: Vec, b: Vec): number {
  let s = 0;
  for (let i = 0; i < a.length; i++) s += (a[i]! - b[i]!) ** 2;
  return Math.sqrt(s / a.length);
}

const d2 = (a: Point, b: Point) => Math.hypot(a.x - b.x, a.y - b.y);

/** Finger extension: tip further from wrist than PIP joint. */
export function fingerStates(lm: Point[]) {
  const w = lm[0]!;
  const ext = (tip: number, pip: number) => d2(lm[tip]!, w) > d2(lm[pip]!, w) * 1.1;
  const palm = d2(lm[0]!, lm[9]!);
  return {
    thumb: d2(lm[4]!, lm[5]!) > palm * 0.55 && d2(lm[4]!, lm[17]!) > d2(lm[3]!, lm[17]!),
    index: ext(8, 6),
    middle: ext(12, 10),
    ring: ext(16, 14),
    pinky: ext(20, 18),
    palm,
  };
}

const near = (lm: Point[], a: number, b: number, palm: number, k = 0.35) => d2(lm[a]!, lm[b]!) / palm < k;

/** Direction the index finger points (image space, y grows downward). */
function pointing(lm: Point[], base = 5, tip = 8) {
  const dx = lm[tip]!.x - lm[base]!.x;
  const dy = lm[tip]!.y - lm[base]!.y;
  const len = Math.hypot(dx, dy) || 1;
  return { sideways: Math.abs(dx) > Math.abs(dy) * 1.2, down: dy / len > 0.5 };
}

/** Rule-based static handshapes for the ASL alphabet (J and Z are motion, handled in SignRecognizer). */
export function classifyLetter(lm: Point[]): { label: string; confidence: number } | null {
  const f = fingerStates(lm);
  const { index: i, middle: m, ring: r, pinky: p, thumb: t, palm } = f;
  const tipGap = d2(lm[8]!, lm[12]!) / palm;
  const thumbIndex = d2(lm[4]!, lm[8]!) / palm;
  const dir = pointing(lm);

  if (i && m && r && p) return t ? null : { label: "B", confidence: 0.85 };
  if (!i && m && r && p && thumbIndex < 0.35) return { label: "F", confidence: 0.75 };
  if (i && m && r && !p) return { label: "W", confidence: 0.8 };
  if (i && m && !r && !p) {
    if (dir.down) return { label: "P", confidence: 0.6 };
    if (dir.sideways) return { label: "H", confidence: 0.7 };
    const crossed = Math.sign(lm[8]!.x - lm[12]!.x) !== Math.sign(lm[5]!.x - lm[9]!.x);
    if (crossed) return { label: "R", confidence: 0.65 };
    if (t && near(lm, 4, 10, palm, 0.45)) return { label: "K", confidence: 0.6 };
    return { label: tipGap > 0.35 ? "V" : "U", confidence: 0.8 };
  }
  if (i && !m && !r && !p) {
    if (dir.down) return { label: "Q", confidence: 0.6 };
    if (dir.sideways) return { label: "G", confidence: 0.65 };
    return { label: t ? "L" : "D", confidence: 0.8 };
  }
  if (!i && !m && !r && p) return { label: t ? "Y" : "I", confidence: 0.8 };
  if (!i && !m && !r && !p) {
    // Hooked index: PIP raised clearly above the other knuckles.
    if (d2(lm[6]!, lm[0]!) > d2(lm[10]!, lm[0]!) * 1.12 && d2(lm[8]!, lm[0]!) > d2(lm[12]!, lm[0]!) * 1.15)
      return { label: "X", confidence: 0.55 };
    if (thumbIndex < 0.3) return { label: "O", confidence: 0.65 };
    if (thumbIndex > 0.9) return { label: "C", confidence: 0.55 };
    const tipsToThumb = [8, 12, 16, 20].reduce((a, k) => a + d2(lm[k]!, lm[4]!), 0) / 4 / palm;
    if (tipsToThumb < 0.45) return { label: "E", confidence: 0.55 };
    if (t) return { label: "A", confidence: 0.6 };
    if (near(lm, 4, 6, palm, 0.3)) return { label: "T", confidence: 0.5 };
    if (near(lm, 4, 14, palm, 0.3)) return { label: "M", confidence: 0.5 };
    if (near(lm, 4, 10, palm, 0.3)) return { label: "N", confidence: 0.5 };
    return { label: "S", confidence: 0.6 };
  }
  return null;
}

/** Built-in whole-word handshapes on one hand. */
export function classifyOneHandWord(lm: Point[]): string | null {
  const f = fingerStates(lm);
  if (f.thumb && f.index && !f.middle && !f.ring && f.pinky) return "I LOVE YOU";
  return null;
}

/** Built-in two-hand signs. */
export function classifyTwoHands(a: Point[], b: Point[]): string | null {
  const la = classifyLetter(a)?.label;
  const lb = classifyLetter(b)?.label;
  const palm = (fingerStates(a).palm + fingerStates(b).palm) / 2;
  const close = (k: number, j: number, lim: number) => d2(a[k]!, b[j]!) / palm < lim;
  const isH = (l?: string) => l === "H" || l === "U";
  const isO = (l?: string) => l === "O" || l === "E";
  const isFist = (l?: string) => l === "A" || l === "S" || l === "T" || l === "M" || l === "N";
  if (isH(la) && isH(lb) && close(6, 6, 1.6)) return "NAME";
  if (isO(la) && isO(lb) && close(8, 8, 0.8)) return "MORE";
  if (isFist(la) && isFist(lb) && close(6, 6, 0.9)) return "HOW ARE YOU?";
  if (la === "Y" && lb === "Y") return "PLAY";
  return null;
}

function changes(xs: number[], eps: number) {
  let c = 0;
  let dir = 0;
  for (let k = 1; k < xs.length; k++) {
    const dx = xs[k]! - xs[k - 1]!;
    if (Math.abs(dx) < eps) continue;
    const nd = Math.sign(dx);
    if (dir && nd !== dir) c++;
    dir = nd;
  }
  return c;
}
const range = (xs: number[]) => Math.max(...xs) - Math.min(...xs);

type Hist = { shape: string | null; wx: number; wy: number; ix: number; iy: number; px: number; py: number; ti: number };

/**
 * Per-frame recognizer for up to two hands. Priority: custom motion → built-in motion
 * (HELLO, YES, NO, THANK YOU, J, Z) → two-hand signs → one-hand words → custom handshape → letters.
 */
export class SignRecognizer {
  private hist: Hist[] = [];
  private motion: Vec[] = [];
  private cooldown = 0;
  private stab = new Stabilizer(8);

  step(hands: Point[][], signs: CustomSign[]): { live: string | null; emit: string | null } {
    const lm = hands[0];
    if (!lm) {
      this.hist = [];
      this.motion = [];
      this.stab.push(null);
      return { live: null, emit: null };
    }
    const f = fingerStates(lm);
    const letter = classifyLetter(lm)?.label ?? null;
    this.hist.push({ shape: letter, wx: lm[0]!.x, wy: lm[0]!.y, ix: lm[8]!.x, iy: lm[8]!.y, px: lm[20]!.x, py: lm[20]!.y, ti: d2(lm[4]!, lm[8]!) / f.palm });
    if (this.hist.length > 30) this.hist.shift();
    this.motion.push(motionFrame(lm));
    if (this.motion.length > 30) this.motion.shift();
    if (this.cooldown > 0) this.cooldown--;

    const fire = (label: string) => {
      this.cooldown = 30;
      this.hist = [];
      this.motion = [];
      return { live: label, emit: label };
    };

    if (this.cooldown === 0 && this.hist.length >= 14) {
      const h = this.hist.slice(-20);
      const share = (pred: (s: string | null) => boolean) => h.filter((x) => pred(x.shape)).length / h.length;
      const wx = h.map((x) => x.wx);
      const wy = h.map((x) => x.wy);
      const dyn = this.motion.length >= 20 ? matchDynamic(this.motion.slice(-24), signs) : null;
      if (dyn) return fire(dyn.label);
      const open = f.index && f.middle && f.ring && f.pinky;
      if (detectWave(wx, open)) return fire("HELLO");
      if (share((s) => s === "B") > 0.7 && wy[wy.length - 1]! - wy[0]! > 0.12 && range(wx) < 0.12) return fire("THANK YOU");
      if (share((s) => s === "A" || s === "S") > 0.7 && range(wy) > 0.05 && changes(wy, 0.004) >= 2) return fire("YES");
      const ti = h.map((x) => x.ti);
      if (range(ti) > 0.5 && changes(ti, 0.03) >= 2 && f.index && f.middle && !f.ring) return fire("NO");
      if (share((s) => s === "I") > 0.6 && range(h.map((x) => x.py)) > 0.08 && range(h.map((x) => x.px)) > 0.04) return fire("J");
      const ix = h.map((x) => x.ix);
      if (share((s) => s === "D" || s === "G" || s === "L") > 0.6 && range(ix) > 0.12 && range(h.map((x) => x.iy)) > 0.06 && changes(ix, 0.006) >= 2)
        return fire("Z");
    }

    let label: string | null = null;
    if (hands[1]) label = classifyTwoHands(lm, hands[1]);
    label ??= classifyOneHandWord(lm);
    label ??= matchStatic(normalize(lm), signs)?.label ?? null;
    label ??= letter;
    return { live: label, emit: this.stab.push(label) };
  }
}

export const BUILT_IN_LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("");
export const BUILT_IN_WORDS = ["HELLO", "THANK YOU", "YES", "NO", "I LOVE YOU", "NAME", "MORE", "PLAY", "HOW ARE YOU?"];

/** Resample a variable-length frame sequence to fixed length (linear interpolation). */
export function resample(seq: Vec[], n = SEQ_LEN): Vec[] {
  if (seq.length === 0) return [];
  if (seq.length === 1) return Array.from({ length: n }, () => seq[0]!);
  const out: Vec[] = [];
  for (let k = 0; k < n; k++) {
    const t = (k / (n - 1)) * (seq.length - 1);
    const a = Math.floor(t);
    const b = Math.min(a + 1, seq.length - 1);
    const f = t - a;
    out.push(seq[a]!.map((v, j) => v * (1 - f) + seq[b]![j]! * f));
  }
  return out;
}

/** Motion frame = hand shape (63) + wrist position in image space (2) so movement matters. */
export function motionFrame(lm: Point[]): Vec {
  return [...normalize(lm), lm[0]!.x * 3, lm[0]!.y * 3];
}

export function seqDist(a: Vec[], b: Vec[]): number {
  let s = 0;
  for (let k = 0; k < a.length; k++) s += dist(a[k]!, b[k]!);
  return s / a.length;
}

export type CustomSign = {
  id: string;
  label: string;
  kind: "static" | "dynamic";
  samples: Vec[] | Vec[][];
};

export const STATIC_THRESHOLD = 0.12;
export const DYNAMIC_THRESHOLD = 0.22;

/** Nearest-neighbour match over every stored sample of every custom static sign. */
export function matchStatic(v: Vec, signs: CustomSign[]) {
  let best: { label: string; d: number } | null = null;
  for (const s of signs) {
    if (s.kind !== "static") continue;
    for (const sample of s.samples as Vec[]) {
      const d = dist(v, sample);
      if (!best || d < best.d) best = { label: s.label, d };
    }
  }
  return best && best.d < STATIC_THRESHOLD ? best : null;
}

export function matchDynamic(seq: Vec[], signs: CustomSign[]) {
  const q = resample(seq);
  let best: { label: string; d: number } | null = null;
  for (const s of signs) {
    if (s.kind !== "dynamic") continue;
    for (const sample of s.samples as Vec[][]) {
      const d = seqDist(q, sample);
      if (!best || d < best.d) best = { label: s.label, d };
    }
  }
  return best && best.d < DYNAMIC_THRESHOLD ? best : null;
}

/** Built-in motion sign: open-hand wave (HELLO) = wrist x oscillates with ≥2 direction changes. */
export function detectWave(wristX: number[], open: boolean): boolean {
  if (!open || wristX.length < 12) return false;
  const range = Math.max(...wristX) - Math.min(...wristX);
  if (range < 0.08) return false;
  let changes = 0;
  let dir = 0;
  for (let k = 1; k < wristX.length; k++) {
    const dx = wristX[k]! - wristX[k - 1]!;
    if (Math.abs(dx) < 0.004) continue;
    const nd = Math.sign(dx);
    if (dir && nd !== dir) changes++;
    dir = nd;
  }
  return changes >= 2;
}

/** Emits a label only after it is stable for `need` consecutive frames. */
export class Stabilizer {
  private last = "";
  private count = 0;
  private emitted = "";
  constructor(private need = 8) {}
  push(label: string | null): string | null {
    if (!label) {
      this.last = "";
      this.count = 0;
      this.emitted = "";
      return null;
    }
    if (label === this.last) this.count++;
    else {
      this.last = label;
      this.count = 1;
    }
    if (this.count >= this.need && this.emitted !== label) {
      this.emitted = label;
      return label;
    }
    return null;
  }
}

/** Letters join into words; whole-word signs get their own spaced token. */
export function appendSign(prev: string, label: string) {
  if (label.length === 1 && /[A-Z]/.test(label)) return prev + label;
  return (prev ? prev.trimEnd() + " " : "") + label + " ";
}
