import { describe, expect, it } from "vitest";
import { Stabilizer, detectWave, matchStatic, resample } from "./sign-engine";

describe("sign engine", () => {
  it("emits a label only after 8 stable frames", () => {
    const s = new Stabilizer(8);
    for (let i = 0; i < 7; i++) expect(s.push("A")).toBeNull();
    expect(s.push("A")).toBe("A");
    expect(s.push("A")).toBeNull();
  });

  it("resamples any sequence to 20 frames", () => {
    expect(resample([[0], [1], [2]]).length).toBe(20);
  });

  it("matches a custom static sign within threshold and rejects far ones", () => {
    const signs = [{ id: "1", label: "MY-NAME", kind: "static" as const, samples: [[0, 0, 0]] }];
    expect(matchStatic([0.05, 0, 0], signs)?.label).toBe("MY-NAME");
    expect(matchStatic([1, 1, 1], signs)).toBeNull();
  });

  it("detects a wave only with an open hand moving back and forth", () => {
    const xs = [0.4, 0.45, 0.5, 0.55, 0.5, 0.45, 0.4, 0.45, 0.5, 0.55, 0.5, 0.45];
    expect(detectWave(xs, true)).toBe(true);
    expect(detectWave(xs, false)).toBe(false);
  });
});

import { BUILT_IN_LETTERS } from "./sign-engine";
describe("built-ins", () => {
  it("covers all 26 letters", () => {
    expect(BUILT_IN_LETTERS.join("")).toBe("ABCDEFGHIJKLMNOPQRSTUVWXYZ");
  });
});
