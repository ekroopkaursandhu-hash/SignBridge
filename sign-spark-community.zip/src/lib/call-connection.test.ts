import { describe, expect, it, vi } from "vitest";
import { CallConnection } from "./call-connection";

function fakePeer() {
  return {
    signalingState: "stable",
    remoteDescription: null as RTCSessionDescriptionInit | null,
    localDescription: null as RTCSessionDescriptionInit | null,
    onicecandidate: null,
    createOffer: vi.fn(async () => ({ type: "offer", sdp: "offer" })),
    createAnswer: vi.fn(async () => ({ type: "answer", sdp: "answer" })),
    setLocalDescription: vi.fn(async function (this: ReturnType<typeof fakePeer>, sdp: RTCSessionDescriptionInit) {
      this.localDescription = sdp;
      this.signalingState = sdp.type === "offer" ? "have-local-offer" : "stable";
    }),
    setRemoteDescription: vi.fn(async function (this: ReturnType<typeof fakePeer>, sdp: RTCSessionDescriptionInit) { this.remoteDescription = sdp; }),
    addIceCandidate: vi.fn(async () => {}),
    close: vi.fn(),
  };
}

describe("Call connection", () => {
  it("elects exactly one offer maker when both callers join the same room together", async () => {
    const a = fakePeer();
    const b = fakePeer();
    const error = vi.fn();
    const ca = new CallConnection(a as unknown as RTCPeerConnection, "a", vi.fn(), error);
    const cb = new CallConnection(b as unknown as RTCPeerConnection, "b", vi.fn(), error);
    await Promise.all([ca.receive("hello", { from: "b" }), cb.receive("hello", { from: "a" })]);
    await ca.receive("ready", { from: "b", to: "a" });
    expect(a.createOffer).toHaveBeenCalledTimes(1);
    expect(b.createOffer).not.toHaveBeenCalled();
    expect(error).not.toHaveBeenCalled();
  });

  it("replays early ICE candidates after receiving the remote description", async () => {
    const peer = fakePeer();
    const connection = new CallConnection(peer as unknown as RTCPeerConnection, "b", vi.fn(), vi.fn());
    const candidate = { candidate: "early-candidate" };
    await connection.receive("ice", { from: "a", to: "b", candidate });
    expect(peer.addIceCandidate).not.toHaveBeenCalled();
    await connection.receive("offer", { from: "a", to: "b", sdp: { type: "offer", sdp: "offer" } });
    expect(peer.addIceCandidate).toHaveBeenCalledWith(candidate);
    expect(peer.createAnswer).toHaveBeenCalledTimes(1);
  });

  it("ignores self messages and signaling targeted to another caller", async () => {
    const peer = fakePeer();
    const connection = new CallConnection(peer as unknown as RTCPeerConnection, "a", vi.fn(), vi.fn());
    await connection.receive("hello", { from: "a" });
    await connection.receive("hello", { from: "b", to: "c" });
    expect(peer.createOffer).not.toHaveBeenCalled();
  });

  it("serializes concurrent messages until the remote description is ready", async () => {
    const peer = fakePeer();
    let release: (() => void) | undefined;
    peer.setRemoteDescription.mockImplementation(async (sdp) => {
      await new Promise<void>((resolve) => { release = resolve; });
      peer.remoteDescription = sdp;
    });
    const connection = new CallConnection(peer as unknown as RTCPeerConnection, "b", vi.fn(), vi.fn());
    const offer = connection.receive("offer", { from: "a", sdp: { type: "offer", sdp: "offer" } });
    const ice = connection.receive("ice", { from: "a", candidate: { candidate: "candidate" } });
    await Promise.resolve();
    expect(peer.addIceCandidate).not.toHaveBeenCalled();
    release?.();
    await Promise.all([offer, ice]);
    expect(peer.addIceCandidate).toHaveBeenCalledTimes(1);
  });
});