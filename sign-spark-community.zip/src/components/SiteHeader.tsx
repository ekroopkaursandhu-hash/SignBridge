import { Link } from "@tanstack/react-router";
import { Hand } from "lucide-react";

export function SiteHeader() {
  const nav = "rounded-full px-3 py-1.5 text-sm font-medium transition-colors";
  const active = { className: "bg-primary text-primary-foreground" };
  const inactive = { className: "text-muted-foreground hover:text-foreground" };
  return (
    <header className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-4 px-5 py-5">
      <Link to="/" className="flex items-center gap-2 font-display text-xl font-bold">
        <span className="grid h-9 w-9 place-items-center rounded-xl bg-primary text-primary-foreground">
          <Hand className="h-5 w-5" />
        </span>
        SignBridge
      </Link>
      <nav className="flex flex-wrap items-center gap-1">
        <Link to="/translate" className={nav} activeProps={active} inactiveProps={inactive}>Translate</Link>
        <Link to="/signs" className={nav} activeProps={active} inactiveProps={inactive}>My signs</Link>
        <Link to="/call" className={nav} activeProps={active} inactiveProps={inactive}>Call</Link>
        <Link to="/guide" className={nav} activeProps={active} inactiveProps={inactive}>Guide</Link>
      </nav>
    </header>
  );
}
