import { useEffect, useRef, useState } from "react";
import { SignRecognizer, type CustomSign, type Point } from "@/lib/sign-engine";

const WASM = "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@1.2.2/wasm";
const MODEL =
  "https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task";

const CONNECTIONS: [number, number][] = [
  [0, 1], [1, 2], [2, 3], [3, 4], [0, 5], [5, 6], [6, 7], [7, 8], [5, 9], [9, 10], [10, 11],
  [11, 12], [9, 13], [13, 14], [14, 15], [15, 16], [13, 17], [17, 18], [18, 19], [19, 20], [0, 17],
];

export type FrameInfo = { landmarks: Point[] | null; live: string | null };

type Props = {
  customSigns?: CustomSign[];
  onSign?: (label: string) => void;
  onFrame?: (f: FrameInfo) => void;
  onStream?: (s: MediaStream) => void;
  recognize?: boolean;
  className?: string;
};

export function SignCamera({ customSigns = [], onSign, onFrame, onStream, recognize = true, className }: Props) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [status, setStatus] = useState("Starting camera…");
  const [live, setLive] = useState<string | null>(null);
  const cb = useRef({ onSign, onFrame, customSigns, recognize });
  cb.current = { onSign, onFrame, customSigns, recognize };

  useEffect(() => {
    let stop = false;
    let raf = 0;
    let stream: MediaStream | null = null;
    let landmarker: { detectForVideo: (v: HTMLVideoElement, t: number) => { landmarks: Point[][] }; close: () => void } | null = null;
    const recognizer = new SignRecognizer();

    (async () => {
      try {
        try {
          stream = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 }, audio: !!onStream });
        } catch (error) {
          if (!onStream) throw error;
          stream = await navigator.mediaDevices.getUserMedia({ video: { width: 640, height: 480 }, audio: false });
        }
        if (stop) { stream.getTracks().forEach((t) => t.stop()); return; }
        onStream?.(stream);
        const v = videoRef.current;
        if (!v) { stream.getTracks().forEach((t) => t.stop()); return; }
        v.srcObject = new MediaStream(stream.getVideoTracks());
        await v.play();
        setStatus("Loading hand model…");
        const { FilesetResolver, HandLandmarker } = await import("@mediapipe/tasks-vision");
        const files = await FilesetResolver.forVisionTasks(WASM);
        landmarker = await HandLandmarker.createFromOptions(files, {
          baseOptions: { modelAssetPath: MODEL, delegate: "GPU" },
          runningMode: "VIDEO",
          numHands: 2,
        });
        if (stop) { landmarker.close(); return; }
        setStatus("");
        loop();
      } catch (e) {
        setStatus(e instanceof Error ? `Camera unavailable: ${e.message}` : "Camera unavailable");
      }
    })();

    function loop() {
      if (stop || !landmarker) return;
      const v = videoRef.current;
      const c = canvasRef.current;
      if (v && c && v.readyState >= 2) {
        const res = landmarker.detectForVideo(v, performance.now());
        const hands = res.landmarks ?? [];
        const lm = hands[0] ?? null;
        c.width = v.videoWidth;
        c.height = v.videoHeight;
        const ctx = c.getContext("2d");
        if (!ctx) { raf = requestAnimationFrame(loop); return; }
        ctx.clearRect(0, 0, c.width, c.height);
        let label: string | null = null;
        for (const hand of hands) {
          const css = getComputedStyle(c);
          ctx.strokeStyle = css.getPropertyValue("--landmark-line").trim() || "teal";
          ctx.fillStyle = css.getPropertyValue("--landmark-dot").trim() || "coral";
          ctx.lineWidth = 3;
          for (const [a, b] of CONNECTIONS) {
            const start = hand[a];
            const end = hand[b];
            if (!start || !end) continue;
            ctx.beginPath();
            ctx.moveTo(start.x * c.width, start.y * c.height);
            ctx.lineTo(end.x * c.width, end.y * c.height);
            ctx.stroke();
          }
          for (const p of hand) {
            ctx.beginPath();
            ctx.arc(p.x * c.width, p.y * c.height, 4, 0, Math.PI * 2);
            ctx.fill();
          }
        }
        if (cb.current.recognize) {
          const r = recognizer.step(hands, cb.current.customSigns);
          label = r.live;
          if (r.emit) cb.current.onSign?.(r.emit);
        }
        setLive(label);
        cb.current.onFrame?.({ landmarks: lm, live: label });
      }
      raf = requestAnimationFrame(loop);
    }

    return () => {
      stop = true;
      cancelAnimationFrame(raf);
      landmarker?.close();
      stream?.getTracks().forEach((t) => t.stop());
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className={`camera-frame ${className ?? ""}`}>
      <video ref={videoRef} playsInline muted className="h-full w-full -scale-x-100 object-cover" />
      <canvas ref={canvasRef} className="pointer-events-none absolute inset-0 h-full w-full -scale-x-100 object-cover" />
      {status && (
        <div className="absolute inset-0 flex items-center justify-center bg-foreground/60 p-6 text-center text-background">
          {status}
        </div>
      )}
      {live && recognize && <div className="sign-chip absolute left-3 top-3">{live}</div>}
    </div>
  );
}
