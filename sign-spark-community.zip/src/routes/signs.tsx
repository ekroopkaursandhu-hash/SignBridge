import { createFileRoute } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { toast } from "sonner";
import { Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { SignCamera, type FrameInfo } from "@/components/SignCamera";
import { useCustomSigns } from "@/hooks/useCustomSigns";
import { motionFrame, normalize, resample, type Vec } from "@/lib/sign-engine";

export const Route = createFileRoute("/signs")({
  head: () => ({
    meta: [
      { title: "Train your own signs — SignBridge" },
      { name: "description", content: "Record name signs, regional slang, or jargon so the translator learns them." },
      { property: "og:title", content: "Train your own signs — SignBridge" },
      { property: "og:description", content: "Record name signs, regional slang, or jargon so the translator learns them." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Signs,
});

const STATIC_SAMPLES = 15;
const DYNAMIC_TAKES = 3;
const TAKE_MS = 1500;

function Signs() {
  const { signs, add, remove } = useCustomSigns();
  const [label, setLabel] = useState("");
  const [kind, setKind] = useState<"static" | "dynamic">("static");
  const [progress, setProgress] = useState("");
  const frame = useRef<FrameInfo>({ landmarks: null, live: null });
  const [testing, setTesting] = useState("");

  const wait = (ms: number) => new Promise((r) => setTimeout(r, ms));

  async function record() {
    const name = label.trim().toUpperCase();
    if (!name) { toast.error("Give your sign a name first"); return; }
    let samples: Vec[] | Vec[][] = [];
    if (kind === "static") {
      const out: Vec[] = [];
      for (let n = 3; n > 0; n--) { setProgress(`Hold your handshape… ${n}`); await wait(700); }
      while (out.length < STATIC_SAMPLES) {
        const lm = frame.current.landmarks;
        if (lm) out.push(normalize(lm));
        setProgress(`Capturing ${out.length}/${STATIC_SAMPLES}`);
        await wait(80);
      }
      samples = out;
    } else {
      const takes: Vec[][] = [];
      for (let t = 0; t < DYNAMIC_TAKES; t++) {
        for (let n = 3; n > 0; n--) { setProgress(`Take ${t + 1}/${DYNAMIC_TAKES} in ${n}…`); await wait(600); }
        setProgress(`Take ${t + 1}: perform the motion now`);
        const seq: Vec[] = [];
        const end = performance.now() + TAKE_MS;
        while (performance.now() < end) {
          const lm = frame.current.landmarks;
          if (lm) seq.push(motionFrame(lm));
          await wait(33);
        }
        if (seq.length < 8) { setProgress(""); toast.error("Couldn't see your hand — try again in better light"); return; }
        takes.push(resample(seq));
      }
      samples = takes;
    }
    add({ id: crypto.randomUUID(), label: name, kind, samples });
    setProgress("");
    toast.success(`“${name}” saved — try it on the translator`);
    setLabel("");
  }


  return (
    <main className="mx-auto grid max-w-6xl gap-6 px-5 pb-16 lg:grid-cols-[1.4fr_1fr]">
      <div className="space-y-3">
        <SignCamera customSigns={signs} onFrame={(f) => (frame.current = f)} onSign={(l) => setTesting(l)} recognize={!progress} />
        {progress && <div className="caption-bar text-center">{progress}</div>}
        {testing && !progress && <div className="text-sm text-muted-foreground">Last recognized: <b className="text-foreground">{testing}</b></div>}
      </div>
      <section className="panel p-6">
        <h1 className="text-2xl font-bold">Teach a new sign</h1>
        <p className="mt-1 text-sm text-muted-foreground">Name signs, local slang, workplace jargon — anything.</p>
        <div className="mt-4 grid gap-3">
          <Input placeholder="e.g. EKROOP or COFFEE" value={label} onChange={(e) => setLabel(e.target.value)} />
          <div className="grid grid-cols-2 gap-2">
            <Button variant={kind === "static" ? "default" : "outline"} onClick={() => setKind("static")}>Handshape</Button>
            <Button variant={kind === "dynamic" ? "default" : "outline"} onClick={() => setKind("dynamic")}>Motion</Button>
          </div>
          <p className="text-xs text-muted-foreground">
            {kind === "static" ? `Captures ${STATIC_SAMPLES} frames of a held handshape.` : `Records ${DYNAMIC_TAKES} short takes of the movement.`}
          </p>
          <Button variant="secondary" disabled={!!progress} onClick={record}>Record</Button>
        </div>
        <h2 className="mt-8 text-lg font-bold">Your signs</h2>
        <ul className="mt-2 divide-y">
          {signs.length === 0 && <li className="py-3 text-sm text-muted-foreground">None yet.</li>}
          {signs.map((s) => (
            <li key={s.id} className="flex items-center justify-between py-2.5">
              <span className="font-display font-semibold">{s.label} <span className="ml-1 text-xs font-normal text-muted-foreground">{s.kind === "static" ? "handshape" : "motion"}</span></span>
              <Button variant="ghost" size="icon" aria-label={`Delete ${s.label}`} onClick={() => remove(s.id)}><Trash2 className="h-4 w-4" /></Button>
            </li>
          ))}
        </ul>
      </section>
    </main>
  );
}
