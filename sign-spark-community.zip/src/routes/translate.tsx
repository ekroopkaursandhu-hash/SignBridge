import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Volume2, Eraser } from "lucide-react";
import { Button } from "@/components/ui/button";
import { SignCamera } from "@/components/SignCamera";
import { useCustomSigns } from "@/hooks/useCustomSigns";
import { appendSign, BUILT_IN_LETTERS, BUILT_IN_WORDS } from "@/lib/sign-engine";

export const Route = createFileRoute("/translate")({
  head: () => ({
    meta: [
      { title: "Live ASL translator — SignBridge" },
      { name: "description", content: "Sign in front of your camera and see fingerspelling and signs turned into text live." },
      { property: "og:title", content: "Live ASL translator — SignBridge" },
      { property: "og:description", content: "Sign in front of your camera and see it turned into text live." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Translate,
});


function Translate() {
  const { signs } = useCustomSigns();
  const [text, setText] = useState("");

  return (
    <main className="mx-auto grid max-w-6xl gap-6 px-5 pb-16 lg:grid-cols-[1.4fr_1fr]">
      <SignCamera customSigns={signs} onSign={(l) => setText((t) => appendSign(t, l))} />
      <section className="panel flex flex-col p-6">
        <h1 className="text-2xl font-bold">Transcript</h1>
        <p className="mt-1 text-sm text-muted-foreground">Hold a handshape steady for a moment. Both hands are tracked. See the Guide for how to make each sign.</p>
        <div className="mt-4 min-h-40 flex-1 rounded-xl bg-muted p-4 font-display text-2xl break-words">{text || <span className="text-muted-foreground">…</span>}</div>
        <div className="mt-4 flex flex-wrap gap-2">
          <Button variant="secondary" onClick={() => setText((t) => t + " ")}>Space</Button>
          <Button variant="secondary" onClick={() => setText((t) => t.slice(0, -1))}>Backspace</Button>
          <Button variant="outline" onClick={() => setText("")}><Eraser className="mr-1 h-4 w-4" />Clear</Button>
          <Button onClick={() => speechSynthesis.speak(new SpeechSynthesisUtterance(text))} disabled={!text}>
            <Volume2 className="mr-1 h-4 w-4" />Speak
          </Button>
        </div>
        <div className="mt-6 text-sm text-muted-foreground">
          <div className="font-semibold text-foreground">Built-in letters</div>
          <div className="mt-2 flex flex-wrap gap-1.5">{BUILT_IN_LETTERS.map((l) => <span key={l} className="rounded-md bg-secondary px-2 py-0.5 font-display">{l}</span>)}</div>
          <div className="mt-4 font-semibold text-foreground">Built-in words</div>
          <div className="mt-2 flex flex-wrap gap-1.5">{BUILT_IN_WORDS.map((w) => <span key={w} className="rounded-md bg-secondary px-2 py-0.5 font-display">{w}</span>)}</div>
          <div className="mt-3">+ {signs.length} of your own signs</div>
        </div>
      </section>
    </main>
  );
}
