import { createFileRoute, Link } from "@tanstack/react-router";
import { Hand, Sparkles, Video } from "lucide-react";
import { Button } from "@/components/ui/button";
import hero from "@/assets/hero-signing.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "SignBridge — Live ASL translation and video calls" },
      { name: "description", content: "Real-time ASL translation, custom sign training, and captioned video calls between Deaf and hearing people." },
      { property: "og:title", content: "SignBridge — Live ASL translation and video calls" },
      { property: "og:description", content: "Real-time ASL translation, custom sign training, and captioned video calls." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Index,
});

const FEATURES = [
  { icon: Hand, title: "Live translation", body: "Fingerspelling and motion signs become text right in your browser — nothing leaves your device." },
  { icon: Sparkles, title: "Teach it your signs", body: "Record your name sign, local slang, or work jargon in seconds. The translator learns instantly." },
  { icon: Video, title: "Captioned calls", body: "Video chat where signs become captions and speech becomes text, both ways." },
];

function Index() {
  return (
    <main className="mx-auto max-w-6xl px-5 pb-20">
      <section className="grid items-center gap-10 py-8 lg:grid-cols-2">
        <div>
          <p className="inline-block rounded-full bg-secondary px-3 py-1 text-sm font-semibold text-primary">For Deaf, hard-of-hearing & hearing people</p>
          <h1 className="mt-5 text-5xl font-extrabold leading-[1.02] md:text-6xl">
            Every hand has <span className="text-accent">something to say.</span>
          </h1>
          <p className="mt-5 max-w-lg text-lg text-muted-foreground">
            SignBridge reads American Sign Language from your camera in real time, learns the signs that are uniquely yours, and puts live captions on every call.
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Button asChild size="lg"><Link to="/translate">Try the translator</Link></Button>
            <Button asChild size="lg" variant="outline"><Link to="/call">Start a call</Link></Button>
          </div>
        </div>
        <img src={hero} alt="Two friends signing to each other at a cafe" className="aspect-[4/3] w-full rounded-[2rem] object-cover shadow-[var(--shadow-soft)]" />
      </section>
      <section className="mt-10 grid gap-5 md:grid-cols-3">
        {FEATURES.map((f) => (
          <div key={f.title} className="panel p-6">
            <f.icon className="h-7 w-7 text-accent" />
            <h2 className="mt-4 text-xl font-bold">{f.title}</h2>
            <p className="mt-2 text-muted-foreground">{f.body}</p>
          </div>
        ))}
      </section>
    </main>
  );
}
