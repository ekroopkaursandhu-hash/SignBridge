import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";

export const Route = createFileRoute("/guide")({
  head: () => ({
    meta: [
      { title: "How to use SignBridge — Guide" },
      { name: "description", content: "Step-by-step guides for the translator, custom signs, and video calls, plus how to form each letter." },
      { property: "og:title", content: "How to use SignBridge — Guide" },
      { property: "og:description", content: "Step-by-step guides plus how to form each supported letter." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Guide,
});

const GUIDES = [
  {
    title: "Translate signs to text",
    to: "/translate" as const,
    steps: [
      "Open Translate and allow camera access when your browser asks.",
      "Sit about an arm's length away, facing a light source — not a bright window behind you.",
      "Raise one or both hands so they are fully on screen. You'll see coloured dots on your fingers.",
      "Form a letter and hold it still for about half a second. It appears in the transcript.",
      "To repeat a letter, drop your hand out of view briefly, then sign it again.",
      "Wave an open hand side to side to say “HELLO”. Use Space, Backspace, and Speak as needed.",
    ],
  },
  {
    title: "Teach your own sign",
    to: "/signs" as const,
    steps: [
      "Open My signs and type a name for the sign, e.g. your name sign or a slang word.",
      "Choose Handshape for a held shape, or Motion for a sign that moves.",
      "Press Record. Wait for the countdown, then make the sign.",
      "Handshape: hold still until 15 frames are captured. Motion: repeat the movement for each of the 3 takes.",
      "Test it right away — the last recognised sign shows under the camera.",
      "Signs are saved on this device and work in Translate and Call too.",
    ],
  },
  {
    title: "Make a captioned call",
    to: "/call" as const,
    steps: [
      "Open Call, press Generate a code, and share the code with your friend.",
      "Both of you enter the same code and press Join, then allow camera and microphone.",
      "Your signs build a caption under your video — press Send to post it to the chat.",
      "Your friend sees your caption live on their screen as you sign.",
      "Hearing callers can type, or tap the mic and speak (works best in Chrome).",
      "If you can't connect, try both being on the same Wi-Fi or a phone hotspot.",
    ],
  },
];

const LETTERS = [
  ["A", "Fist, thumb resting against the side of your index finger."],
  ["B", "Four fingers straight up and together, thumb folded across your palm."],
  ["C", "Curve all fingers and thumb into a C shape."],
  ["D", "Index finger up; other fingertips touch the thumb."],
  ["E", "Curl all fingertips down onto your thumb, which is tucked across the palm."],
  ["F", "Touch index tip to thumb tip; other three fingers straight up."],
  ["G", "Index finger and thumb point sideways, parallel, other fingers closed."],
  ["H", "Index and middle fingers together, pointing sideways."],
  ["I", "Pinky up, other fingers in a fist, thumb across them."],
  ["J", "Make an I, then draw a J in the air with your pinky."],
  ["K", "Index and middle up in a V, thumb tip touching the middle finger."],
  ["L", "Index finger up and thumb out to the side, making an L."],
  ["M", "Fist with the thumb tucked under your first three fingers."],
  ["N", "Fist with the thumb tucked under your first two fingers."],
  ["O", "Curve fingers so the fingertips touch the thumb tip, making an O."],
  ["P", "Like K, but tipped so the fingers point down."],
  ["Q", "Like G, but tipped so index and thumb point down."],
  ["R", "Cross your middle finger over your index finger."],
  ["S", "Fist, thumb wrapped across the front of your fingers."],
  ["T", "Fist with the thumb tucked between index and middle fingers."],
  ["U", "Index and middle fingers up and pressed together."],
  ["V", "Index and middle fingers up and spread apart."],
  ["W", "Index, middle, and ring fingers up and spread."],
  ["X", "Index finger bent into a hook, other fingers closed."],
  ["Y", "Thumb and pinky out, middle three fingers folded."],
  ["Z", "Index finger out, draw a Z in the air."],
];

const WORDS = [
  ["HELLO", "Open hand, wave side to side."],
  ["THANK YOU", "Flat hand (B), fingers up, move it down and away from you."],
  ["YES", "Fist (S), nod it up and down like a head nodding."],
  ["NO", "Index and middle fingers snap closed onto the thumb, twice."],
  ["I LOVE YOU", "Thumb, index and pinky up; middle and ring folded."],
  ["NAME", "Both hands in H shape, tap one pair of fingers across the other."],
  ["MORE", "Both hands in a flat O, tap the fingertips together."],
  ["PLAY", "Both hands in Y shape, shake them."],
  ["HOW ARE YOU?", "Both hands in loose fists, knuckles together, roll them forward."],
];

function Guide() {
  return (
    <main className="mx-auto max-w-6xl px-5 pb-20">
      <h1 className="text-4xl font-extrabold">How to use SignBridge</h1>
      <p className="mt-2 text-muted-foreground">No account needed — just open a page and allow your camera.</p>

      <div className="mt-8 grid gap-5 lg:grid-cols-3">
        {GUIDES.map((g) => (
          <section key={g.title} className="panel flex flex-col p-6">
            <h2 className="text-xl font-bold">{g.title}</h2>
            <ol className="mt-4 flex-1 space-y-3">
              {g.steps.map((s, i) => (
                <li key={i} className="flex gap-3 text-sm">
                  <span className="grid h-6 w-6 shrink-0 place-items-center rounded-full bg-primary text-xs font-bold text-primary-foreground">{i + 1}</span>
                  <span>{s}</span>
                </li>
              ))}
            </ol>
            <Button asChild className="mt-6"><Link to={g.to}>Open</Link></Button>
          </section>
        ))}
      </div>

      <section className="panel mt-10 p-6">
        <h2 className="text-2xl font-bold">Letters the translator knows (A–Z)</h2>
        <p className="mt-1 text-sm text-muted-foreground">Show your palm to the camera unless noted. Teach any other letter or word in My signs.</p>
        <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {LETTERS.map(([l, d]) => (
            <div key={l} className="flex items-start gap-3 rounded-xl bg-muted p-3">
              <span className="sign-chip shrink-0">{l}</span>
              <span className="text-sm">{d}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="panel mt-6 p-6">
        <h2 className="text-2xl font-bold">Built-in words</h2>
        <p className="mt-1 text-sm text-muted-foreground">Two-hand signs need both hands fully in view. Motion signs need a clear, steady movement.</p>
        <div className="mt-5 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {WORDS.map(([w, d]) => (
            <div key={w} className="flex flex-col gap-2 rounded-xl bg-muted p-3">
              <span className="sign-chip self-start text-base">{w}</span>
              <span className="text-sm">{d}</span>
            </div>
          ))}
        </div>
      </section>
    </main>
  );
}
