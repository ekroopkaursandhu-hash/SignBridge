import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { toast } from "sonner";
import { Mic, Send, PhoneOff, Volume2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { SignCamera } from "@/components/SignCamera";
import { useCustomSigns } from "@/hooks/useCustomSigns";
import { supabase } from "@/integrations/supabase/client";
import { appendSign } from "@/lib/sign-engine";
import type { RealtimeChannel } from "@supabase/supabase-js";
import { CallConnection, type CallSignal } from "@/lib/call-connection";

export const Route = createFileRoute("/call")({
  head: () => ({
    meta: [
      { title: "Video call with live captions — SignBridge" },
      { name: "description", content: "Video chat between Deaf, hard-of-hearing, and hearing people with live ASL captions." },
      { property: "og:title", content: "Video call with live captions — SignBridge" },
      { property: "og:description", content: "Video chat with live ASL captions and speech-to-text." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary" },
    ],
  }),
  component: Call,
});

type Msg = { from: string; text: string; kind: "chat" | "sign" | "speech" };
const ICE = [{ urls: "stun:stun.l.google.com:19302" }, { urls: "stun:stun1.l.google.com:19302" }];

function Call() {
  const [room, setRoom] = useState("");
  const [joined, setJoined] = useState<string | null>(null);
  return joined ? (
    <Room code={joined} onLeave={() => setJoined(null)} />
  ) : (
    <main className="mx-auto max-w-md px-5 py-10">
      <div className="panel p-8">
        <h1 className="text-3xl font-bold">Start a call</h1>
        <p className="mt-2 text-sm text-muted-foreground">Share the room code with the person you want to talk to. Both of you join the same code.</p>
        <div className="mt-6 flex gap-2">
          <Input placeholder="Room code" value={room} onChange={(e) => setRoom(e.target.value.toUpperCase())} />
          <Button disabled={!room.trim()} onClick={() => setJoined(room.trim().toUpperCase())}>Join</Button>
        </div>
        <Button variant="link" className="mt-2 px-0" onClick={() => setRoom(Math.random().toString(36).slice(2, 8).toUpperCase())}>Generate a code</Button>
      </div>
    </main>
  );
}

function Room({ code, onLeave }: { code: string; onLeave: () => void }) {
  const { signs } = useCustomSigns();
  const myId = useRef(crypto.randomUUID());
  const name = useRef(`Guest ${Math.floor(Math.random() * 900 + 100)}`).current;
  const remoteVideo = useRef<HTMLVideoElement>(null);
  const chan = useRef<RTCChannelLike | null>(null);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [connected, setConnected] = useState(false);
  const [connectionStatus, setConnectionStatus] = useState("Starting camera…");
  const [restart, setRestart] = useState(0);
  const [soundEnabled, setSoundEnabled] = useState(false);
  const [myCaption, setMyCaption] = useState("");
  const [theirCaption, setTheirCaption] = useState("");
  const [msgs, setMsgs] = useState<Msg[]>([]);
  const [draft, setDraft] = useState("");
  const [listening, setListening] = useState(false);

  useEffect(() => {
    if (!stream) return;
    const peer = new RTCPeerConnection({ iceServers: ICE });
    let active = true;
    let subscribed = false;
    setConnected(false);
    setConnectionStatus("Joining room…");
    stream.getTracks().forEach((t) => peer.addTrack(t, stream));
    const remoteStream = new MediaStream();
    peer.ontrack = (e) => {
      remoteStream.addTrack(e.track);
      if (remoteVideo.current) {
        remoteVideo.current.srcObject = remoteStream;
        void remoteVideo.current.play().catch(() => setConnectionStatus("Select Enable sound to play the call."));
      }
    };
    peer.onconnectionstatechange = () => {
      if (!active) return;
      setConnected(peer.connectionState === "connected");
      if (peer.connectionState === "connected") setConnectionStatus("Connected");
      else if (peer.connectionState === "connecting") setConnectionStatus("Connecting to caller…");
      else if (peer.connectionState === "failed") setConnectionStatus("Video connection failed. Try another network and rejoin.");
      else if (peer.connectionState === "disconnected") setConnectionStatus("Caller disconnected. Reconnecting…");
    };

    const channel: RealtimeChannel = supabase.channel(`call:${code}`, { config: { broadcast: { self: false } } });
    const send = (event: string, payload: Record<string, unknown>) => {
      if (!active || !subscribed) return;
      void channel.send({ type: "broadcast", event, payload: { ...payload, from: myId.current } }).then((result) => {
        if (active && result !== "ok") setConnectionStatus("Room connection interrupted. Please rejoin.");
      });
    };
    chan.current = { send };
    const connection = new CallConnection(peer, myId.current, send, () => {
      if (active) setConnectionStatus("Unable to connect to caller. Please leave and rejoin.");
    });
    for (const event of ["hello", "ready", "offer", "answer", "ice"]) {
      channel.on("broadcast", { event }, ({ payload }) => { void connection.receive(event, payload as CallSignal); });
    }

    channel
      .on("broadcast", { event: "bye" }, () => { if (active) { setTheirCaption(""); setRestart((n) => n + 1); } })
      .on("broadcast", { event: "caption" }, ({ payload }) => setTheirCaption(payload.text))
      .on("broadcast", { event: "msg" }, ({ payload }) => setMsgs((m) => [...m, { from: payload.name, text: payload.text, kind: payload.kind }]))
      .subscribe((s) => {
        if (!active) return;
        subscribed = s === "SUBSCRIBED";
        if (subscribed) { setConnectionStatus("Waiting for someone to join…"); send("hello", {}); }
        else if (["CHANNEL_ERROR", "TIMED_OUT", "CLOSED"].includes(s)) setConnectionStatus("Cannot reach the room. Check your internet connection and rejoin.");
      });
    const heartbeat = window.setInterval(() => {
      if (peer.connectionState === "new") send("hello", {});
    }, 3000);

    return () => {
      active = false;
      chan.current = null;
      window.clearInterval(heartbeat);
      connection.close();
      if (remoteVideo.current) remoteVideo.current.srcObject = null;
      void supabase.removeChannel(channel);
    };
  }, [stream, code, restart]);

  function post(text: string, kind: Msg["kind"]) {
    if (!text.trim()) return;
    setMsgs((m) => [...m, { from: name, text, kind }]);
    chan.current?.send("msg", { name, text, kind });
  }

  function onSign(label: string) {
    setMyCaption((prev) => {
      const next = appendSign(prev, label).slice(-60);
      chan.current?.send("caption", { text: next });
      return next;
    });
  }

  function sendCaption() {
    post(myCaption.trim(), "sign");
    setMyCaption("");
    chan.current?.send("caption", { text: "" });
  }

  function listen() {
    const SR = (window as unknown as { SpeechRecognition?: new () => SpeechRec; webkitSpeechRecognition?: new () => SpeechRec }).SpeechRecognition
      ?? (window as unknown as { webkitSpeechRecognition?: new () => SpeechRec }).webkitSpeechRecognition;
    if (!SR) { toast.error("Speech-to-text isn't supported in this browser (try Chrome)."); return; }
    const r = new SR();
    r.lang = "en-US";
    r.onresult = (e) => post(e.results[0][0].transcript, "speech");
    r.onend = () => setListening(false);
    setListening(true);
    r.start();
  }

  return (
    <main className="mx-auto max-w-6xl px-5 pb-16">
      <div className="mb-4 flex items-center justify-between">
        <h1 className="text-2xl font-bold">Room <span className="text-primary">{code}</span></h1>
        <Button variant="destructive" onClick={() => { chan.current?.send("bye", {}); onLeave(); }}><PhoneOff className="mr-1 h-4 w-4" />Leave</Button>
      </div>
      <div className="grid gap-6 lg:grid-cols-[1fr_1fr_0.9fr]">
        <div className="space-y-2">
          <div className="text-sm font-semibold text-muted-foreground">You</div>
          <SignCamera customSigns={signs} onSign={onSign} onStream={setStream} />
          <div className="flex gap-2">
            <div className="caption-bar min-h-10 flex-1">{myCaption || "Your signs appear here…"}</div>
            <Button variant="secondary" onClick={sendCaption} disabled={!myCaption.trim()}>Send</Button>
          </div>
        </div>
        <div className="space-y-2">
          <div role="status" className="text-sm font-semibold text-muted-foreground">{connected ? "Them · Connected" : connectionStatus}</div>
          <div className="camera-frame">
            <video ref={remoteVideo} aria-label="Other caller" autoPlay playsInline muted={!soundEnabled} className="h-full w-full object-cover" />
            {theirCaption && <div className="caption-bar absolute inset-x-3 bottom-3">{theirCaption}</div>}
          </div>
          <Button variant="outline" disabled={!connected} onClick={() => {
            setSoundEnabled((enabled) => !enabled);
            const video = remoteVideo.current;
            if (video) { video.muted = soundEnabled; void video.play().catch(() => toast.error("Could not play the call. Please try again.")); }
          }}><Volume2 className="mr-2 h-4 w-4" />{soundEnabled ? "Mute sound" : "Enable sound"}</Button>
        </div>
        <section className="panel flex h-[28rem] flex-col p-4">
          <div className="flex-1 space-y-2 overflow-y-auto">
            {msgs.length === 0 && <p className="text-sm text-muted-foreground">Signs, speech, and typed messages all show up here.</p>}
            {msgs.map((m, i) => (
              <div key={i} className="rounded-xl bg-muted px-3 py-2 text-sm">
                <b>{m.from}</b> <span className="text-xs text-muted-foreground">{m.kind === "sign" ? "signed" : m.kind === "speech" ? "said" : "typed"}</span>
                <div>{m.text}</div>
              </div>
            ))}
          </div>
          <form className="mt-3 flex gap-2" onSubmit={(e) => { e.preventDefault(); post(draft, "chat"); setDraft(""); }}>
            <Input value={draft} onChange={(e) => setDraft(e.target.value)} placeholder="Type a message" />
            <Button type="button" variant={listening ? "default" : "outline"} size="icon" aria-label="Speak" onClick={listen}><Mic className="h-4 w-4" /></Button>
            <Button type="submit" size="icon" aria-label="Send"><Send className="h-4 w-4" /></Button>
          </form>
        </section>
      </div>
    </main>
  );
}

type RTCChannelLike = { send: (event: string, payload: Record<string, unknown>) => unknown };
type SpeechRec = {
  lang: string;
  start: () => void;
  onresult: (e: { results: { 0: { 0: { transcript: string } } } }) => void;
  onend: () => void;
};
