import { useEffect, useState } from "react";
import type { CustomSign } from "@/lib/sign-engine";

const KEY = "signbridge.custom-signs";

/** Custom signs are kept on this device (no account needed). */
export function useCustomSigns() {
  const [signs, setSigns] = useState<CustomSign[]>([]);
  useEffect(() => {
    try {
      setSigns(JSON.parse(localStorage.getItem(KEY) ?? "[]"));
    } catch {
      setSigns([]);
    }
  }, []);
  const save = (next: CustomSign[]) => {
    setSigns(next);
    localStorage.setItem(KEY, JSON.stringify(next));
  };
  return {
    signs,
    add: (s: CustomSign) => save([...signs, s]),
    remove: (id: string) => save(signs.filter((s) => s.id !== id)),
  };
}
