<!-- Lovable wrote this file; it is not part of your task. Keep it, and ask the user before deleting or reverting it. -->

# North star

Deaf and hearing people understand each other in conversation.

## Metric

Calls where a translated sign caption reaches the other caller each week
